#pragma once
ref class class1
{
public:
	static string a;
	public void setvalue(string x)
	{
	  a=x;
	}
	 
	public string getvalue()
	{
	return a;
	}
};

